
            <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>", "Exito");
            <?php endif; ?>

            <?php if(session('danger')): ?>
            toastr.error("<?php echo e(session('danger')); ?>", "Error");
            <?php endif; ?>

            <?php if(session('warning')): ?>
            toastr.warning("<?php echo e(session('warning')); ?>", "Peligro");
            <?php endif; ?>

            <?php if($errors->any()): ?>
            toastr.error("<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>", "Error");
            <?php endif; ?>
<?php /**PATH C:\laragon\www\GestionBodega\resources\views/layout/alerts.blade.php ENDPATH**/ ?>